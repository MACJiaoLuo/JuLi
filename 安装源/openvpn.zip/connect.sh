#!/bin/sh
#-----------------------------------
#	聚力网络科技 www.juliwangluo.cn
#	       如非必要 请勿修改 
#        何以潇QQ：1744744222
#-----------------------------------
# 用户名 虚拟IP PID
php /var/www/html/openvpn_api/connect.php "$username" "$ifconfig_pool_local_ip" "$daemon_pid"
exit 0
