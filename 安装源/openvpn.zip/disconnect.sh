#!/bin/sh
#-----------------------------------
#	聚力网络科技 www.juliwangluo.cn
#	       如非必要 请勿修改 
#        何以潇QQ：1744744222
#-----------------------------------
cd /var/www/html/
php openvpn_api/disconnect.php "$common_name" "$bytes_received" "$bytes_sent"